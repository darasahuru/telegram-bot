<?php
if (!defined('ABSPATH')) {
    exit;
}

class DH_Response
{
    public static function success($data = [], $message = 'Success')
    {
        return rest_ensure_response([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }

    public static function error($message, $status = 400)
    {
        return new WP_Error(
            'dh_error',
            $message,
            [
                'status' => $status
            ]
        );
    }
}
