<?php
if (!defined('ABSPATH')) {
    exit;
}

class DH_Loader
{
    public static function init()
    {
        require_once DHBOT_PLUGIN_DIR . 'includes/class-response.php';
        require_once DHBOT_PLUGIN_DIR . 'includes/class-api.php';

        new DH_API();
    }
}
