<?php
if (!defined('ABSPATH')) {
    exit;
}

class DH_API
{
    const API_NAMESPACE = 'darasahuru/v1';

    public function __construct()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes()
    {
        require DHBOT_PLUGIN_DIR . 'routes/status.php';
    }
}
