<?php
/**
 * Plugin Name: Darasa Huru Bot API
 * Plugin URI: https://darasahuru.net
 * Description: REST API for the Darasa Huru Telegram Bot.
 * Version: 0.1.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Darasa Huru
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('DHBOT_VERSION', '0.1.0');
define('DHBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DHBOT_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once DHBOT_PLUGIN_DIR . 'includes/class-loader.php';

DH_Loader::init();
