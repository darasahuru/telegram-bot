<?php
if (!defined('ABSPATH')) {
    exit;
}

register_rest_route(
    DH_API::API_NAMESPACE,
    '/status',
    [
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function () {

            return DH_Response::success([
                'plugin' => 'Darasa Huru Bot API',
                'version' => DHBOT_VERSION,
                'wordpress' => get_bloginfo('version'),
                'php' => PHP_VERSION,
                'time' => current_time('mysql')
            ]);
        }
    ]
);
